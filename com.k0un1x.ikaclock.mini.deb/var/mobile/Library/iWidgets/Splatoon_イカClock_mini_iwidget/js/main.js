﻿
function updateClock() {
                var objToday = new Date(),
                dayOfWeek = weekday[objToday.getDay()],
                dayOfMonth = objToday.getDate(),
                curMonth = months[objToday.getMonth()],
                curHour = objToday.getHours(),
                curMinute = objToday.getMinutes() < 10 ? '0' + objToday.getMinutes() : objToday.getMinutes(),
                curSeconds = objToday.getSeconds() < 10 ? '0' + objToday.getSeconds() : objToday.getSeconds(),
                curMeridiem = objToday.getHours() < 12 ? 'AM' : 'PM';

                if (xhour == false) {
                     curHour = (curHour < 10 ? '0' : '') + curHour;
                } else {
                     curHour = (curHour > 12) ? curHour - 12 : curHour;
                     curHour = (curHour == 0) ? 12 : curHour;
                }

                     $('#hour').html(curHour);
                     $('#colon').html(':');
                     $('#minute').html(curMinute);
                     $('#colon2').html(':');
                     if (seconds == true) $('#second').html(curSeconds);
                     if (ampm == true) $('#meridiem').html(curMeridiem);
			         if (lang == 'en') $('#date').html(dayOfWeek + ', ' + curMonth + ' ' + dayOfMonth);
			         else $('#date').html(dayOfWeek + ', ' + dayOfMonth + '. ' + curMonth);
}

function init() {
                if (black == true) {
                    $('#hour').css('color', '#000');
                    $('#colon').css('color', '#000');
                    $('#minute').css('color', '#000');
                    $('#colon2').css('color', '#000');
                    $('#second').css('color', '#000');
                    $('#meridiem').css('color', '#000');
                    $('#date').css('color', '#000');
                }
              updateClock();
              setInterval(updateClock, 1000);
}